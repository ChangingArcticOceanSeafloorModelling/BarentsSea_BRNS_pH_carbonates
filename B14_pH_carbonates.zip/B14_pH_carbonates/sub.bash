#!/bin/sh -l 
#PBS -l walltime=72:00:00
#PBS -o testlogfile 
#PBS -e test.err 
#PBS -N coast_highk

cd /home/borowik/B14_Carb

./brns
